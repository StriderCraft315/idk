import discord
from discord.ext import commands
from discord import ui
import pylxd
import json

client = pylxd.Client()
config = json.load(open("config.json"))
LOGO = config.get("brand_logo")

def is_admin(uid):
    return str(uid) in config["admin_ids"]

class ManageView(ui.View):
    def __init__(self, name, owner):
        super().__init__(timeout=None)
        self.name = name
        self.owner = owner

    def auth(self,interaction):
        return interaction.user.id==self.owner or is_admin(interaction.user.id)

class Manage(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def manage(self, ctx):
        await ctx.send("Manage working.")

async def setup(bot):
    await bot.add_cog(Manage(bot))
