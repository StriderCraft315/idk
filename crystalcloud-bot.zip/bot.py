import discord
from discord.ext import commands
import asyncio
import json

config = json.load(open("config.json"))
intents = discord.Intents.all()
bot = commands.Bot(command_prefix='.', intents=intents)

EXTENSIONS = [
    "modules.commands",
    "modules.manage"
]

async def load_extensions():
    for ext in EXTENSIONS:
        try:
            await bot.load_extension(ext)
            print(f"Loaded: {ext}")
        except Exception as e:
            print(f"Failed {ext}: {e}")

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}")

async def main():
    await load_extensions()
    await bot.start(config["bot_token"])

asyncio.run(main())
