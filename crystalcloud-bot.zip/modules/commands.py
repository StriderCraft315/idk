import discord
from discord.ext import commands
import pylxd
import json

client = pylxd.Client()
config = json.load(open("config.json"))
LOGO = config.get("brand_logo")

def is_admin(uid):
    return str(uid) in config["admin_ids"]

class Commands(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def help(self, ctx):
        await ctx.send("Help works.")

    @commands.command()
    async def plans(self, ctx):
        await ctx.send("Plans here.")

async def setup(bot):
    await bot.add_cog(Commands(bot))
